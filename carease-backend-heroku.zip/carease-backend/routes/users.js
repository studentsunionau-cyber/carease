// routes/users.js - User Management Routes
const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticateToken } = require('../middleware/auth');

/**
 * @route   GET /api/users/profile
 * @desc    Get current user profile
 * @access  Private
 */
router.get('/profile', authenticateToken, async (req, res) => {
  try {
    const result = await query(
      `SELECT 
        u.id, u.email, u.first_name, u.last_name, u.phone,
        u.is_student, u.student_verified, u.student_institution,
        u.student_email, u.user_type, u.created_at,
        p.address, p.city, p.state, p.postcode,
        p.license_number, p.license_verified, p.profile_photo
       FROM users u
       LEFT JOIN user_profiles p ON u.id = p.user_id
       WHERE u.id = $1`,
      [req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user: result.rows[0] });

  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ error: 'Error fetching profile' });
  }
});

/**
 * @route   PUT /api/users/profile
 * @desc    Update user profile
 * @access  Private
 */
router.put('/profile', authenticateToken, async (req, res) => {
  try {
    const {
      firstName, lastName, phone, address, city, state, postcode
    } = req.body;

    // Update users table
    if (firstName || lastName || phone) {
      await query(
        `UPDATE users SET
          first_name = COALESCE($1, first_name),
          last_name = COALESCE($2, last_name),
          phone = COALESCE($3, phone),
          updated_at = CURRENT_TIMESTAMP
         WHERE id = $4`,
        [firstName, lastName, phone, req.user.id]
      );
    }

    // Update user_profiles table
    if (address || city || state || postcode) {
      await query(
        `UPDATE user_profiles SET
          address = COALESCE($1, address),
          city = COALESCE($2, city),
          state = COALESCE($3, state),
          postcode = COALESCE($4, postcode),
          updated_at = CURRENT_TIMESTAMP
         WHERE user_id = $5`,
        [address, city, state, postcode, req.user.id]
      );
    }

    // Get updated profile
    const result = await query(
      `SELECT 
        u.id, u.email, u.first_name, u.last_name, u.phone,
        u.is_student, u.student_verified,
        p.address, p.city, p.state, p.postcode
       FROM users u
       LEFT JOIN user_profiles p ON u.id = p.user_id
       WHERE u.id = $1`,
      [req.user.id]
    );

    res.json({
      message: 'Profile updated successfully',
      user: result.rows[0]
    });

  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Error updating profile' });
  }
});

/**
 * @route   POST /api/users/verify-student
 * @desc    Submit student verification
 * @access  Private
 */
router.post('/verify-student', authenticateToken, async (req, res) => {
  try {
    const { studentIdDocument } = req.body;

    if (!studentIdDocument) {
      return res.status(400).json({ error: 'Student ID document URL required' });
    }

    // Update user profile
    await query(
      `UPDATE user_profiles SET
        student_id_document = $1,
        updated_at = CURRENT_TIMESTAMP
       WHERE user_id = $2`,
      [studentIdDocument, req.user.id]
    );

    // Note: Student verification approval happens in admin panel

    res.json({ 
      message: 'Student verification submitted. Will be reviewed within 24 hours.' 
    });

  } catch (error) {
    console.error('Submit student verification error:', error);
    res.status(500).json({ error: 'Error submitting verification' });
  }
});

/**
 * @route   GET /api/users/stats
 * @desc    Get user statistics
 * @access  Private
 */
router.get('/stats', authenticateToken, async (req, res) => {
  try {
    const stats = await query(
      `SELECT 
        COUNT(*) FILTER (WHERE status = 'completed') as total_bookings,
        COUNT(*) FILTER (WHERE status IN ('pending', 'confirmed', 'active')) as active_bookings,
        COALESCE(SUM(discount_amount) FILTER (WHERE status = 'completed'), 0) as total_savings,
        COALESCE(SUM(total_price) FILTER (WHERE status = 'completed'), 0) as total_spent
       FROM bookings
       WHERE user_id = $1`,
      [req.user.id]
    );

    res.json({ stats: stats.rows[0] });

  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({ error: 'Error fetching stats' });
  }
});

module.exports = router;
