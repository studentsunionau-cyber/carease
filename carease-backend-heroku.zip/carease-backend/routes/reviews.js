// routes/reviews.js - Review Management Routes
const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticateToken } = require('../middleware/auth');

/**
 * @route   POST /api/reviews
 * @desc    Submit review for booking
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { bookingId, rating, comment } = req.body;

    if (!bookingId || !rating) {
      return res.status(400).json({ error: 'Booking ID and rating required' });
    }

    if (rating < 1 || rating > 5) {
      return res.status(400).json({ error: 'Rating must be between 1 and 5' });
    }

    // Get booking details
    const bookingResult = await query(
      'SELECT * FROM bookings WHERE id = $1',
      [bookingId]
    );

    if (bookingResult.rows.length === 0) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    const booking = bookingResult.rows[0];

    // Check if user made this booking
    if (booking.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized to review this booking' });
    }

    // Check if booking is completed
    if (booking.status !== 'completed') {
      return res.status(400).json({ error: 'Can only review completed bookings' });
    }

    // Check if review already exists
    const existingReview = await query(
      'SELECT id FROM reviews WHERE booking_id = $1',
      [bookingId]
    );

    if (existingReview.rows.length > 0) {
      return res.status(400).json({ error: 'Review already submitted for this booking' });
    }

    // Create review
    const result = await query(
      `INSERT INTO reviews (booking_id, user_id, vehicle_id, rating, comment)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [bookingId, req.user.id, booking.vehicle_id, rating, comment]
    );

    res.status(201).json({
      message: 'Review submitted successfully',
      review: result.rows[0]
    });

  } catch (error) {
    console.error('Submit review error:', error);
    res.status(500).json({ error: 'Error submitting review' });
  }
});

/**
 * @route   GET /api/reviews/vehicle/:vehicleId
 * @desc    Get reviews for a vehicle
 * @access  Public
 */
router.get('/vehicle/:vehicleId', async (req, res) => {
  try {
    const { vehicleId } = req.params;
    const { page = 1, limit = 10 } = req.query;

    const offset = (page - 1) * limit;

    const result = await query(
      `SELECT 
        r.*,
        u.first_name || ' ' || u.last_name as reviewer_name,
        b.start_date, b.end_date
       FROM reviews r
       JOIN users u ON r.user_id = u.id
       JOIN bookings b ON r.booking_id = b.id
       WHERE r.vehicle_id = $1
       ORDER BY r.created_at DESC
       LIMIT $2 OFFSET $3`,
      [vehicleId, limit, offset]
    );

    // Get total count
    const countResult = await query(
      'SELECT COUNT(*) FROM reviews WHERE vehicle_id = $1',
      [vehicleId]
    );

    res.json({
      reviews: result.rows,
      pagination: {
        total: parseInt(countResult.rows[0].count),
        page: parseInt(page),
        limit: parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Get reviews error:', error);
    res.status(500).json({ error: 'Error fetching reviews' });
  }
});

module.exports = router;
