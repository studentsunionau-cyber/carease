// routes/admin.js - Admin Panel Routes
const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticateToken, requireAdmin } = require('../middleware/auth');

// All admin routes require authentication and admin role
router.use(authenticateToken);
router.use(requireAdmin);

/**
 * @route   GET /api/admin/stats
 * @desc    Get dashboard statistics
 * @access  Admin only
 */
router.get('/stats', async (req, res) => {
  try {
    const stats = await query(`
      SELECT 
        (SELECT COUNT(*) FROM users WHERE is_active = true) as total_users,
        (SELECT COUNT(*) FROM users WHERE is_student = true AND student_verified = true) as verified_students,
        (SELECT COUNT(*) FROM vehicles WHERE is_available = true) as available_vehicles,
        (SELECT COUNT(*) FROM bookings WHERE status IN ('pending', 'confirmed', 'active')) as active_bookings,
        (SELECT COUNT(*) FROM bookings WHERE status = 'completed') as completed_bookings,
        (SELECT COALESCE(SUM(total_price), 0) FROM bookings WHERE status = 'completed') as total_revenue,
        (SELECT COALESCE(SUM(total_price), 0) FROM bookings 
         WHERE status = 'completed' AND created_at >= CURRENT_DATE - INTERVAL '30 days') as monthly_revenue,
        (SELECT COUNT(*) FROM users WHERE is_student = true AND student_verified = false) as pending_verifications
    `);

    res.json({ stats: stats.rows[0] });

  } catch (error) {
    console.error('Get admin stats error:', error);
    res.status(500).json({ error: 'Error fetching statistics' });
  }
});

/**
 * @route   GET /api/admin/users
 * @desc    Get all users
 * @access  Admin only
 */
router.get('/users', async (req, res) => {
  try {
    const { page = 1, limit = 20, search } = req.query;
    const offset = (page - 1) * limit;

    let searchCondition = '';
    let params = [limit, offset];

    if (search) {
      searchCondition = `WHERE u.email ILIKE $3 OR u.first_name ILIKE $3 OR u.last_name ILIKE $3`;
      params.push(`%${search}%`);
    }

    const result = await query(
      `SELECT 
        u.id, u.email, u.first_name, u.last_name, u.phone,
        u.is_student, u.student_verified, u.user_type, u.is_active,
        u.created_at,
        COUNT(b.id) as total_bookings
       FROM users u
       LEFT JOIN bookings b ON u.id = b.user_id
       ${searchCondition}
       GROUP BY u.id
       ORDER BY u.created_at DESC
       LIMIT $1 OFFSET $2`,
      params
    );

    const countResult = await query(
      `SELECT COUNT(*) FROM users u ${searchCondition}`,
      search ? [`%${search}%`] : []
    );

    res.json({
      users: result.rows,
      pagination: {
        total: parseInt(countResult.rows[0].count),
        page: parseInt(page),
        limit: parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ error: 'Error fetching users' });
  }
});

/**
 * @route   POST /api/admin/verify-student/:userId
 * @desc    Approve or reject student verification
 * @access  Admin only
 */
router.post('/verify-student/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { approved } = req.body;

    if (approved === undefined) {
      return res.status(400).json({ error: 'Approval status required' });
    }

    await query(
      'UPDATE users SET student_verified = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
      [approved, userId]
    );

    res.json({
      message: `Student verification ${approved ? 'approved' : 'rejected'} successfully`
    });

  } catch (error) {
    console.error('Verify student error:', error);
    res.status(500).json({ error: 'Error updating verification status' });
  }
});

/**
 * @route   PUT /api/admin/users/:id/suspend
 * @desc    Suspend or unsuspend user
 * @access  Admin only
 */
router.put('/users/:id/suspend', async (req, res) => {
  try {
    const { id } = req.params;
    const { suspend } = req.body;

    await query(
      'UPDATE users SET is_active = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
      [!suspend, id]
    );

    res.json({
      message: `User ${suspend ? 'suspended' : 'activated'} successfully`
    });

  } catch (error) {
    console.error('Suspend user error:', error);
    res.status(500).json({ error: 'Error updating user status' });
  }
});

/**
 * @route   GET /api/admin/bookings
 * @desc    Get all bookings
 * @access  Admin only
 */
router.get('/bookings', async (req, res) => {
  try {
    const { page = 1, limit = 20, status } = req.query;
    const offset = (page - 1) * limit;

    let statusCondition = '';
    let params = [limit, offset];

    if (status) {
      statusCondition = 'WHERE b.status = $3';
      params.push(status);
    }

    const result = await query(
      `SELECT 
        b.*,
        u.first_name || ' ' || u.last_name as customer_name,
        u.email as customer_email,
        v.make || ' ' || v.model as vehicle_name,
        v.rego
       FROM bookings b
       JOIN users u ON b.user_id = u.id
       JOIN vehicles v ON b.vehicle_id = v.id
       ${statusCondition}
       ORDER BY b.created_at DESC
       LIMIT $1 OFFSET $2`,
      params
    );

    const countResult = await query(
      `SELECT COUNT(*) FROM bookings ${status ? 'WHERE status = $1' : ''}`,
      status ? [status] : []
    );

    res.json({
      bookings: result.rows,
      pagination: {
        total: parseInt(countResult.rows[0].count),
        page: parseInt(page),
        limit: parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Get bookings error:', error);
    res.status(500).json({ error: 'Error fetching bookings' });
  }
});

/**
 * @route   GET /api/admin/vehicles
 * @desc    Get all vehicles
 * @access  Admin only
 */
router.get('/vehicles', async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const result = await query(
      `SELECT 
        v.*,
        u.first_name || ' ' || u.last_name as owner_name,
        u.email as owner_email,
        COUNT(b.id) as total_bookings
       FROM vehicles v
       JOIN users u ON v.owner_id = u.id
       LEFT JOIN bookings b ON v.id = b.vehicle_id
       GROUP BY v.id, u.first_name, u.last_name, u.email
       ORDER BY v.created_at DESC
       LIMIT $1 OFFSET $2`,
      [limit, offset]
    );

    const countResult = await query('SELECT COUNT(*) FROM vehicles');

    res.json({
      vehicles: result.rows,
      pagination: {
        total: parseInt(countResult.rows[0].count),
        page: parseInt(page),
        limit: parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Get vehicles error:', error);
    res.status(500).json({ error: 'Error fetching vehicles' });
  }
});

module.exports = router;
