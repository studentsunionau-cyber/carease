// routes/vehicles.js - Vehicle Management Routes
const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticateToken, requireOwner } = require('../middleware/auth');

/**
 * @route   GET /api/vehicles
 * @desc    Get all vehicles with filters
 * @access  Public
 */
router.get('/', async (req, res) => {
  try {
    const {
      city,
      minPrice,
      maxPrice,
      bodyType,
      transmission,
      fuelType,
      startDate,
      endDate,
      seats,
      sortBy = 'created_at',
      order = 'DESC',
      page = 1,
      limit = 20
    } = req.query;

    let conditions = ['v.is_available = true'];
    let params = [];
    let paramCount = 0;

    // City filter
    if (city) {
      paramCount++;
      conditions.push(`LOWER(v.location_city) = LOWER($${paramCount})`);
      params.push(city);
    }

    // Price range
    if (minPrice) {
      paramCount++;
      conditions.push(`v.daily_rate >= $${paramCount}`);
      params.push(minPrice);
    }
    if (maxPrice) {
      paramCount++;
      conditions.push(`v.daily_rate <= $${paramCount}`);
      params.push(maxPrice);
    }

    // Body type filter
    if (bodyType) {
      paramCount++;
      conditions.push(`v.body_type = $${paramCount}`);
      params.push(bodyType);
    }

    // Transmission filter
    if (transmission) {
      paramCount++;
      conditions.push(`v.transmission = $${paramCount}`);
      params.push(transmission);
    }

    // Fuel type filter
    if (fuelType) {
      paramCount++;
      conditions.push(`v.fuel_type = $${paramCount}`);
      params.push(fuelType);
    }

    // Seats filter
    if (seats) {
      paramCount++;
      conditions.push(`v.seats >= $${paramCount}`);
      params.push(seats);
    }

    // Date availability check
    if (startDate && endDate) {
      paramCount++;
      const startParam = paramCount;
      paramCount++;
      const endParam = paramCount;
      
      conditions.push(`
        NOT EXISTS (
          SELECT 1 FROM bookings b
          WHERE b.vehicle_id = v.id
          AND b.status NOT IN ('cancelled')
          AND (
            (b.start_date <= $${startParam} AND b.end_date >= $${startParam})
            OR (b.start_date <= $${endParam} AND b.end_date >= $${endParam})
            OR (b.start_date >= $${startParam} AND b.end_date <= $${endParam})
          )
        )
      `);
      params.push(startDate, endDate);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    // Valid sort fields
    const validSortFields = ['daily_rate', 'average_rating', 'created_at', 'total_reviews'];
    const sortField = validSortFields.includes(sortBy) ? sortBy : 'created_at';
    const sortOrder = order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    // Pagination
    const offset = (page - 1) * limit;

    // Get total count
    const countResult = await query(
      `SELECT COUNT(*) FROM vehicles v ${whereClause}`,
      params
    );
    const totalCount = parseInt(countResult.rows[0].count);

    // Get vehicles
    const result = await query(
      `SELECT 
        v.*,
        u.first_name || ' ' || u.last_name as owner_name,
        u.email as owner_email,
        COALESCE(
          (SELECT json_agg(json_build_object('id', id, 'photo_url', photo_url, 'is_primary', is_primary))
           FROM vehicle_photos WHERE vehicle_id = v.id ORDER BY is_primary DESC, display_order),
          '[]'
        ) as photos
       FROM vehicles v
       LEFT JOIN users u ON v.owner_id = u.id
       ${whereClause}
       ORDER BY v.${sortField} ${sortOrder}
       LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`,
      [...params, limit, offset]
    );

    res.json({
      vehicles: result.rows,
      pagination: {
        total: totalCount,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(totalCount / limit)
      }
    });

  } catch (error) {
    console.error('Get vehicles error:', error);
    res.status(500).json({ error: 'Error fetching vehicles' });
  }
});

/**
 * @route   GET /api/vehicles/:id
 * @desc    Get single vehicle by ID
 * @access  Public
 */
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const result = await query(
      `SELECT 
        v.*,
        u.first_name || ' ' || u.last_name as owner_name,
        u.email as owner_email,
        u.phone as owner_phone,
        COALESCE(
          (SELECT json_agg(json_build_object('id', id, 'photo_url', photo_url, 'is_primary', is_primary, 'display_order', display_order))
           FROM vehicle_photos WHERE vehicle_id = v.id ORDER BY is_primary DESC, display_order),
          '[]'
        ) as photos
       FROM vehicles v
       LEFT JOIN users u ON v.owner_id = u.id
       WHERE v.id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Vehicle not found' });
    }

    // Get reviews
    const reviewsResult = await query(
      `SELECT 
        r.*,
        u.first_name || ' ' || u.last_name as reviewer_name
       FROM reviews r
       LEFT JOIN users u ON r.user_id = u.id
       WHERE r.vehicle_id = $1
       ORDER BY r.created_at DESC
       LIMIT 10`,
      [id]
    );

    const vehicle = result.rows[0];
    vehicle.reviews = reviewsResult.rows;

    res.json({ vehicle });

  } catch (error) {
    console.error('Get vehicle error:', error);
    res.status(500).json({ error: 'Error fetching vehicle' });
  }
});

/**
 * @route   POST /api/vehicles
 * @desc    Create new vehicle
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const {
      make, model, year, color, rego, bodyType, transmission, fuelType,
      seats, dailyRate, weeklyRate, locationCity, locationState,
      locationAddress, description, features
    } = req.body;

    // Validate required fields
    if (!make || !model || !year || !rego || !dailyRate || !locationCity) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Check if rego already exists
    const existingVehicle = await query(
      'SELECT id FROM vehicles WHERE rego = $1',
      [rego]
    );

    if (existingVehicle.rows.length > 0) {
      return res.status(400).json({ error: 'Vehicle with this registration already exists' });
    }

    const result = await query(
      `INSERT INTO vehicles (
        owner_id, make, model, year, color, rego, body_type, transmission,
        fuel_type, seats, daily_rate, weekly_rate, location_city, location_state,
        location_address, description, features
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
      RETURNING *`,
      [
        req.user.id, make, model, year, color, rego, bodyType, transmission,
        fuelType, seats, dailyRate, weeklyRate, locationCity, locationState,
        locationAddress, description, JSON.stringify(features || [])
      ]
    );

    res.status(201).json({
      message: 'Vehicle created successfully',
      vehicle: result.rows[0]
    });

  } catch (error) {
    console.error('Create vehicle error:', error);
    res.status(500).json({ error: 'Error creating vehicle' });
  }
});

/**
 * @route   PUT /api/vehicles/:id
 * @desc    Update vehicle
 * @access  Private (Owner or Admin)
 */
router.put('/:id', authenticateToken, requireOwner, async (req, res) => {
  try {
    const { id } = req.params;
    const {
      make, model, year, color, bodyType, transmission, fuelType,
      seats, dailyRate, weeklyRate, locationCity, locationState,
      locationAddress, description, features, isAvailable
    } = req.body;

    const result = await query(
      `UPDATE vehicles SET
        make = COALESCE($1, make),
        model = COALESCE($2, model),
        year = COALESCE($3, year),
        color = COALESCE($4, color),
        body_type = COALESCE($5, body_type),
        transmission = COALESCE($6, transmission),
        fuel_type = COALESCE($7, fuel_type),
        seats = COALESCE($8, seats),
        daily_rate = COALESCE($9, daily_rate),
        weekly_rate = COALESCE($10, weekly_rate),
        location_city = COALESCE($11, location_city),
        location_state = COALESCE($12, location_state),
        location_address = COALESCE($13, location_address),
        description = COALESCE($14, description),
        features = COALESCE($15, features),
        is_available = COALESCE($16, is_available),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $17
      RETURNING *`,
      [
        make, model, year, color, bodyType, transmission, fuelType,
        seats, dailyRate, weeklyRate, locationCity, locationState,
        locationAddress, description, features ? JSON.stringify(features) : null,
        isAvailable, id
      ]
    );

    res.json({
      message: 'Vehicle updated successfully',
      vehicle: result.rows[0]
    });

  } catch (error) {
    console.error('Update vehicle error:', error);
    res.status(500).json({ error: 'Error updating vehicle' });
  }
});

/**
 * @route   DELETE /api/vehicles/:id
 * @desc    Delete vehicle
 * @access  Private (Owner or Admin)
 */
router.delete('/:id', authenticateToken, requireOwner, async (req, res) => {
  try {
    const { id } = req.params;

    // Check for active bookings
    const activeBookings = await query(
      `SELECT COUNT(*) FROM bookings 
       WHERE vehicle_id = $1 AND status IN ('pending', 'confirmed', 'active')`,
      [id]
    );

    if (parseInt(activeBookings.rows[0].count) > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete vehicle with active bookings' 
      });
    }

    await query('DELETE FROM vehicles WHERE id = $1', [id]);

    res.json({ message: 'Vehicle deleted successfully' });

  } catch (error) {
    console.error('Delete vehicle error:', error);
    res.status(500).json({ error: 'Error deleting vehicle' });
  }
});

/**
 * @route   GET /api/vehicles/:id/availability
 * @desc    Check vehicle availability for date range
 * @access  Public
 */
router.get('/:id/availability', async (req, res) => {
  try {
    const { id } = req.params;
    const { startDate, endDate } = req.query;

    if (!startDate || !endDate) {
      return res.status(400).json({ error: 'Start and end dates required' });
    }

    const result = await query(
      `SELECT 
        CASE 
          WHEN EXISTS (
            SELECT 1 FROM bookings
            WHERE vehicle_id = $1
            AND status NOT IN ('cancelled')
            AND (
              (start_date <= $2 AND end_date >= $2)
              OR (start_date <= $3 AND end_date >= $3)
              OR (start_date >= $2 AND end_date <= $3)
            )
          ) THEN false
          ELSE true
        END as available`,
      [id, startDate, endDate]
    );

    res.json({ available: result.rows[0].available });

  } catch (error) {
    console.error('Check availability error:', error);
    res.status(500).json({ error: 'Error checking availability' });
  }
});

module.exports = router;
