// routes/bookings.js - Booking Management Routes
const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticateToken } = require('../middleware/auth');

/**
 * @route   POST /api/bookings
 * @desc    Create new booking
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { vehicleId, startDate, endDate } = req.body;

    if (!vehicleId || !startDate || !endDate) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Validate dates
    const start = new Date(startDate);
    const end = new Date(endDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (start < today) {
      return res.status(400).json({ error: 'Start date cannot be in the past' });
    }

    if (end <= start) {
      return res.status(400).json({ error: 'End date must be after start date' });
    }

    // Calculate duration
    const durationDays = Math.ceil((end - start) / (1000 * 60 * 60 * 24));

    // Get vehicle details
    const vehicleResult = await query(
      'SELECT * FROM vehicles WHERE id = $1 AND is_available = true',
      [vehicleId]
    );

    if (vehicleResult.rows.length === 0) {
      return res.status(404).json({ error: 'Vehicle not found or not available' });
    }

    const vehicle = vehicleResult.rows[0];

    // Check availability
    const availabilityCheck = await query(
      `SELECT COUNT(*) FROM bookings
       WHERE vehicle_id = $1
       AND status NOT IN ('cancelled')
       AND (
         (start_date <= $2 AND end_date >= $2)
         OR (start_date <= $3 AND end_date >= $3)
         OR (start_date >= $2 AND end_date <= $3)
       )`,
      [vehicleId, startDate, endDate]
    );

    if (parseInt(availabilityCheck.rows[0].count) > 0) {
      return res.status(400).json({ error: 'Vehicle not available for selected dates' });
    }

    // Calculate price
    let basePrice;
    if (durationDays >= 7 && vehicle.weekly_rate) {
      const weeks = Math.floor(durationDays / 7);
      const remainingDays = durationDays % 7;
      basePrice = (weeks * parseFloat(vehicle.weekly_rate)) + 
                  (remainingDays * parseFloat(vehicle.daily_rate));
    } else {
      basePrice = durationDays * parseFloat(vehicle.daily_rate);
    }

    // Apply student discount (50%)
    let discountAmount = 0;
    let discountType = null;

    if (req.user.is_student && req.user.student_verified) {
      discountAmount = basePrice * 0.5;
      discountType = 'student_50_percent';
    }

    const totalPrice = basePrice - discountAmount;

    // Generate booking number
    const bookingNumber = 'CE' + Date.now().toString().slice(-10);

    // Create booking
    const bookingResult = await query(
      `INSERT INTO bookings (
        booking_number, user_id, vehicle_id, start_date, end_date,
        duration_days, base_price, discount_amount, discount_type,
        total_price, status, payment_status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'pending', 'pending')
      RETURNING *`,
      [
        bookingNumber, req.user.id, vehicleId, startDate, endDate,
        durationDays, basePrice, discountAmount, discountType, totalPrice
      ]
    );

    const booking = bookingResult.rows[0];

    // Get full booking details with vehicle info
    const fullBooking = await query(
      `SELECT 
        b.*,
        v.make, v.model, v.year, v.rego, v.location_city,
        u.first_name || ' ' || u.last_name as owner_name
       FROM bookings b
       JOIN vehicles v ON b.vehicle_id = v.id
       JOIN users u ON v.owner_id = u.id
       WHERE b.id = $1`,
      [booking.id]
    );

    res.status(201).json({
      message: 'Booking created successfully',
      booking: fullBooking.rows[0]
    });

  } catch (error) {
    console.error('Create booking error:', error);
    res.status(500).json({ error: 'Error creating booking' });
  }
});

/**
 * @route   GET /api/bookings/my
 * @desc    Get current user's bookings
 * @access  Private
 */
router.get('/my', authenticateToken, async (req, res) => {
  try {
    const { status } = req.query;

    let statusCondition = '';
    let params = [req.user.id];

    if (status) {
      statusCondition = 'AND b.status = $2';
      params.push(status);
    }

    const result = await query(
      `SELECT 
        b.*,
        v.make, v.model, v.year, v.rego, v.location_city, v.location_address,
        u.first_name || ' ' || u.last_name as owner_name,
        u.phone as owner_phone,
        COALESCE(
          (SELECT photo_url FROM vehicle_photos 
           WHERE vehicle_id = v.id AND is_primary = true LIMIT 1),
          (SELECT photo_url FROM vehicle_photos 
           WHERE vehicle_id = v.id LIMIT 1)
        ) as vehicle_photo
       FROM bookings b
       JOIN vehicles v ON b.vehicle_id = v.id
       JOIN users u ON v.owner_id = u.id
       WHERE b.user_id = $1 ${statusCondition}
       ORDER BY b.created_at DESC`,
      params
    );

    res.json({ bookings: result.rows });

  } catch (error) {
    console.error('Get bookings error:', error);
    res.status(500).json({ error: 'Error fetching bookings' });
  }
});

/**
 * @route   GET /api/bookings/:id
 * @desc    Get single booking
 * @access  Private
 */
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    const result = await query(
      `SELECT 
        b.*,
        v.make, v.model, v.year, v.rego, v.location_city, v.location_address,
        v.daily_rate, v.weekly_rate,
        u.first_name || ' ' || u.last_name as owner_name,
        u.phone as owner_phone,
        u.email as owner_email,
        renter.first_name || ' ' || renter.last_name as renter_name,
        renter.phone as renter_phone,
        renter.email as renter_email,
        COALESCE(
          (SELECT json_agg(json_build_object('id', id, 'photo_url', photo_url))
           FROM vehicle_photos WHERE vehicle_id = v.id ORDER BY is_primary DESC LIMIT 3),
          '[]'
        ) as vehicle_photos
       FROM bookings b
       JOIN vehicles v ON b.vehicle_id = v.id
       JOIN users u ON v.owner_id = u.id
       JOIN users renter ON b.user_id = renter.id
       WHERE b.id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    const booking = result.rows[0];

    // Check if user is authorized to view this booking
    if (booking.user_id !== req.user.id && 
        booking.owner_id !== req.user.id && 
        req.user.user_type !== 'admin') {
      return res.status(403).json({ error: 'Not authorized to view this booking' });
    }

    res.json({ booking });

  } catch (error) {
    console.error('Get booking error:', error);
    res.status(500).json({ error: 'Error fetching booking' });
  }
});

/**
 * @route   PUT /api/bookings/:id/cancel
 * @desc    Cancel booking
 * @access  Private
 */
router.put('/:id/cancel', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    // Get booking
    const bookingResult = await query(
      'SELECT * FROM bookings WHERE id = $1',
      [id]
    );

    if (bookingResult.rows.length === 0) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    const booking = bookingResult.rows[0];

    // Check authorization
    if (booking.user_id !== req.user.id && req.user.user_type !== 'admin') {
      return res.status(403).json({ error: 'Not authorized to cancel this booking' });
    }

    // Check if booking can be cancelled
    if (booking.status === 'cancelled') {
      return res.status(400).json({ error: 'Booking already cancelled' });
    }

    if (booking.status === 'completed') {
      return res.status(400).json({ error: 'Cannot cancel completed booking' });
    }

    // Cancel booking
    await query(
      `UPDATE bookings SET 
        status = 'cancelled',
        updated_at = CURRENT_TIMESTAMP
       WHERE id = $1`,
      [id]
    );

    // TODO: Process refund if payment was made

    res.json({ message: 'Booking cancelled successfully' });

  } catch (error) {
    console.error('Cancel booking error:', error);
    res.status(500).json({ error: 'Error cancelling booking' });
  }
});

/**
 * @route   PUT /api/bookings/:id/complete
 * @desc    Mark booking as completed
 * @access  Private (Vehicle owner or admin)
 */
router.put('/:id/complete', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    const result = await query(
      `UPDATE bookings b SET 
        status = 'completed',
        updated_at = CURRENT_TIMESTAMP
       FROM vehicles v
       WHERE b.id = $1
       AND b.vehicle_id = v.id
       AND (v.owner_id = $2 OR $3 = 'admin')
       RETURNING b.*`,
      [id, req.user.id, req.user.user_type]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Booking not found or not authorized' });
    }

    // Update vehicle total bookings
    await query(
      `UPDATE vehicles SET 
        total_bookings = total_bookings + 1
       WHERE id = $1`,
      [result.rows[0].vehicle_id]
    );

    res.json({ 
      message: 'Booking marked as completed',
      booking: result.rows[0]
    });

  } catch (error) {
    console.error('Complete booking error:', error);
    res.status(500).json({ error: 'Error completing booking' });
  }
});

/**
 * @route   GET /api/bookings/vehicle/:vehicleId
 * @desc    Get bookings for a vehicle (for owners)
 * @access  Private (Owner or admin)
 */
router.get('/vehicle/:vehicleId', authenticateToken, async (req, res) => {
  try {
    const { vehicleId } = req.params;

    // Check if user owns this vehicle
    const vehicleCheck = await query(
      'SELECT owner_id FROM vehicles WHERE id = $1',
      [vehicleId]
    );

    if (vehicleCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Vehicle not found' });
    }

    if (vehicleCheck.rows[0].owner_id !== req.user.id && 
        req.user.user_type !== 'admin') {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const result = await query(
      `SELECT 
        b.*,
        u.first_name || ' ' || u.last_name as renter_name,
        u.phone as renter_phone,
        u.email as renter_email
       FROM bookings b
       JOIN users u ON b.user_id = u.id
       WHERE b.vehicle_id = $1
       ORDER BY b.start_date DESC`,
      [vehicleId]
    );

    res.json({ bookings: result.rows });

  } catch (error) {
    console.error('Get vehicle bookings error:', error);
    res.status(500).json({ error: 'Error fetching bookings' });
  }
});

module.exports = router;
